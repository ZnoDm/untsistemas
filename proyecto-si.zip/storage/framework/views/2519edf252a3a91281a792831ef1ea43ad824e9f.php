

<?php $__env->startSection('title', 'Docentes'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Dr. <?php echo e($docente->nombre); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-4">
        <h4>PRACTICAS</h4>
        <?php if($practicas->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NOMBRES</th>                            
                            <th>APELLIDOS</th>
                            <th>TELEFONO</th>
                            <th>EMAIL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $practicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($practica->id); ?></td>
                                <td><?php echo e($practica->nombre); ?></td>
                                <td><?php echo e($practica->apellido); ?></td>
                                <td><?php echo e($practica->telefono); ?></td>
                                <td><?php echo e($practica->email); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="card-body"><strong>No hay registros</strong></div>
        <?php endif; ?>
    </div>
    <div class="p-4">
        <h4>TESIS</h4>
        <?php if($tesis->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombres</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="card-body"><strong>No hay registros</strong></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/admin/docente/show.blade.php ENDPATH**/ ?>