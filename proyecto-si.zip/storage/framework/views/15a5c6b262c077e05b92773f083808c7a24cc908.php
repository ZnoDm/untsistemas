<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('vendor/fontawesome-free/css/all.min.css')); ?>">
        <?php echo \Livewire\Livewire::styles(); ?>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <!-- Scripts -->
        <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
        <style>
            .t-footer{
                color: #E6AD09;
            }
            .t-footer>p,.t-footer>span{
                color: #FFFFFF;
            }
            .t-footer>span>i{
                color: #E6AD09;
            }
        </style>
    </head>
    <body class="font-sans antialiased" >
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.banner','data' => []]); ?>
<?php $component->withName('jet-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <div class="min-h-screen bg-gray-100" style="background:  #12377B">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-menu')->html();
} elseif ($_instance->childHasBeenRendered('uNyztmI')) {
    $componentId = $_instance->getRenderedChildComponentId('uNyztmI');
    $componentTag = $_instance->getRenderedChildComponentTagName('uNyztmI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uNyztmI');
} else {
    $response = \Livewire\Livewire::mount('navigation-menu');
    $html = $response->html();
    $_instance->logRenderedChild('uNyztmI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

            <!-- Page Content -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

    </body>
    <footer style="background:#1B1811">
        <div class="max-w-7xl mx-auto p-10 grid grid-cols-1 gap-4 sm:grid-cols-4" >
            <div class="t-footer">
                <h5>UBICACIÓN</h5>
                <div class="mb-3" style="border-bottom-style: solid; border-bottom-width: 3px; width: 40px;"></div>

                <span>Campus Universitario </span> <br>
                <span>Av. Juan Pablo II S/N </span> <br>
                <span>Trujillo - Perú </span> <br>
                <span>Filiales: </span> <br>
                <span>Sede Huamachuco </span> <br>
                <span>Sede Valle Jequetepeque </span>
            </div>
            <div class="t-footer">
                <h5>CONTACTO</h5>
                <div class="mb-3" style="border-bottom-style: solid; border-bottom-width: 3px; width: 40px;"></div>

                <span><i class="bi bi-telephone-fill"></i> &nbsp; (044) 209020  </span> <br>
                <span><i class="bi bi-envelope"></i> &nbsp; tdsgunt@unitru.edu.pe  </span> <br>
                <span><i class="bi bi-globe"></i> &nbsp; https://www.unitru.edu.pe/ </span>

            </div>
            <div class="t-footer">
                <h5>SOBRE ESTE PORTAL</h5>
                <div class="mb-3" style="border-bottom-style: solid; border-bottom-width: 3px; width: 40px;"></div>

                <span> Mapa de Sitio </span>  <br>
                <span> Términos de uso </span> <br>
                <span> Políticas de Privacidad </span>
            </div>
            <div class="t-footer">
                <h5>SÍGUENOS EN: </h5>
                <div class="mb-3" style="border-bottom-style: solid; border-bottom-width: 3px; width: 40px;"></div>
                <div class="flex" style="color: #FFFFFF!important;">
                    <h2 class="px-2"> <i class="bi bi-facebook"></i></h2>                     
                    <h2 class="px-2"> <i class="bi bi-instagram"></i></h2> 
                    <h2 class="px-2"> <i class="bi bi-twitter"></i></h2> 
                    <h2 class="px-2"> <i class="bi bi-linkedin"></i></h2> 
                </div>
            </div>
        </div>
    </footer>
</html>
<?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/layouts/app.blade.php ENDPATH**/ ?>