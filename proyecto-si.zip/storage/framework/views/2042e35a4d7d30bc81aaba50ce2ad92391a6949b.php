

<?php $__env->startSection('title', 'Tesis Pendientes'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Pendientes de Aprobación</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<hr class="mt-3">
<?php if(session('info')): ?>
    <div class="alert alert-success mt-2" x-data="{open:true}" x-show="open">
        <?php echo e(session('info')); ?>

    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>COD Alumno</th>
                    <th>Solicitud</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tesis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $te): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($te->id); ?></td>
                        <td><?php echo e($te->codigo); ?></td>
                        <td> 
                            <?php if($te->status ==1): ?>
                                SOLICITUD DE TESIS
                            <?php else: ?>
                                INFORME FINAL DE TESIS
                            <?php endif; ?>
                        </td>
                        <td><a href="<?php echo e(route('admin.tesis.revision',$te->id)); ?>" class="btn btn-primary">Revisar</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/admin/tesis/index.blade.php ENDPATH**/ ?>