
<?php $__env->startSection('title', 'Tesis Pendientes'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="d-flex">
        <h1 class="mr-auto">Solicitud de Tesis</h1>
    </div>    
    <hr class="mt-3">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <h2 class="my-5 font-weight-bold text-center"> TESIS </h5>
        <div class="row gx-2">
            <!--ASIDE-->
            <div class="col-4">

                <div class="text-center">
                    <img class="h-16 w-16 rounded-circle img-fluid" style="width: 200px" src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
                </div><br><br>

                <hr class="my-3 mx-4">

                <div class="text-center">
                    <h5 class="pb-3 font-weight-bold">INFORMACION DEL ALUMNO </h5>

                    <p><span class="font-weight-bold">Código de matricula</span> <br> 
                        <?php echo e($tesis->alumno_codigo); ?></p>

                    <p><span class="font-weight-bold">Apellidos y Nombres</span> <br> 
                        <?php echo e($tesis->apellido.' '.$tesis->nombre); ?></p>
                
                </div>        
                <hr class="my-3 mx-4">
                <div class="text-center">
                    <h5 class="pb-3 font-weight-bold">CONTACTO </h5>
                    <p><span class="font-weight-bold"> Email</span> <br>
                    <?php echo e($tesis->email); ?></p>

                    <p><span class="font-weight-bold">Télefono</span> <br>
                        <?php echo e($tesis->telefono); ?></p>  
                </div>
            </div>  

            <div class="col-8 px-3">

                <!--tesis-->

                <h5 class="font-weight-bold">Asunto</h5>
                <p> <span class="">Titulo: </span><?php echo e($tesis->titulo); ?> </p> 

                <p> <span class="">Fecha de Incio: </span><?php echo e($tesis->fecha_inicio); ?> </p> 
                <p> <span class="">Fecha de Fin: </span><?php echo e($tesis->fecha_fin); ?> </p> 

                <div class="d-flex justify-content-center">                    
                    <a href="<?php echo e($tesis->file_tesis); ?>" class="button" download><i class="fa fa-download"></i> Descargar Documento de Tesis</a>
                </div>

                <hr class="my-3 mx-3">
                <?php if($tesis->status ==5): ?>
                    <h5 class="font-weight-bold">INFORME FINAL</h5>
                    <div class="d-flex justify-content-center">                    
                        <a href="<?php echo e($tesis->file_informe_final); ?>" class="button" download><i class="fa fa-download"></i> Revisar informe Final</a>
                    </div>

                    <hr class="my-3 mx-3">
                <?php endif; ?>
                
                <!--VOUCHER-->
                <h5 class="font-weight-bold pb-3"> Voucher </h5>

                <p> <span class="">Numero de Operacion: </span><?php echo e($tesis->tesis_id); ?> </p>

                <div class="d-flex justify-content-center">                    
                    <a href="<?php echo e($tesis->file_voucher); ?>" class="button" download><i class="fa fa-download"></i> Descargar Voucher</a>
                </div>

            </div>
        </div>
        <?php
                if($tesis->status == 5 ) {$estado= 5;} else {$estado= 1;}
        ?>
        <form action="<?php echo e(route('admin.tesis.aprobar',['id'=>$tesis->id,'alumno' =>$tesis->alumno_codigo,'estado' =>$estado])); ?>" method="POST">
            <?php echo csrf_field(); ?>
        <?php if($tesis->status ==5): ?>
        
            <h5 class="font-weight-bold text-center">ASIGNAR JURADO</h5>
            <div class="row px-5">
                <select name="docente_id" id="docente_id" class="form-control w-100" aria-label=".form-select-lg example" onchange="agregar();">
                        <option value="">SELECCIONA UN DOCENTE</option>
                        <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($docente->id); ?>_<?php echo e($docente->nombre); ?>"><?php echo e($docente->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                 <br> <br>
                <table class="table" id="detalle">
                      <tr>
                        <th scope="col">CODIGO</th>
                        <th scope="col">DOCENTE</th>
                        <th scope="col">ACCION</th>
                      </tr>
                </table>

                
            </div>
        <?php endif; ?>
        <div class="d-flex text-center justify-content-center">
            
                <input <?php if($tesis->status ==5): ?>
                disabled
                <?php endif; ?>  type="submit" class="btn btn-success mx-2" id="submit"  value="APROBAR">
                <button type="button" class="btn btn-danger mx-2" data-toggle="modal" data-target="#exampleModal">
                    DENEGAR
                </button>
        </div>
    </form>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Mandar Correcciones</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="p-2">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <label for="descripcion">Observaciones:</label>
                <textarea name="descripcion" id="descripcion" cols="30" rows="10" class="mb-2"></textarea>
                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="submit" value="Enviar" class="btn btn-success w-full btn-block mt-2">
            </form>
        </div>
        
      </div>
    </div>
</div>
<script type="text/javascript">
    var indice=0;
    let temporal=[];
    var suma_jurados=0;
    function agregar()
    {		
        docente=document.getElementById('docente_id').value.split('_');
        if(temporal.indexOf(docente[0])>-1){
            alert('Ya has asignado este jurado');
        }
        else{
            suma_jurados = suma_jurados + 1;
            if(suma_jurados>3){
                suma_jurados = suma_jurados - 1;
                alert('Solo se asignan 3 jurados');
            }else{
                temporal[indice] = docente[0];		
                fila='<tr id="fila'+indice+'"><td><input type="hidden" name="docente_ids[]" value="'+docente[0]+'">'+docente[0]+'</td><td>'+docente[1]+'</td><td><a href="#" onclick="quitar('+indice+')">Quitar</a></td></tr>';
                $('#detalle').append(fila);

                document.getElementById('submit').disabled=false;
                indice++;

                console.log(temporal);

            }
        }
        console.log(suma_jurados);
    }	

    function quitar(item)
    {
        
        temporal.splice(item, 1);
        console.log(temporal);
        $('#fila'+item).remove();
        indice--;
        suma_jurados = suma_jurados - 1;
        if(suma_jurados === 0){
            document.getElementById('submit').disabled=true;
        }
        console.log(suma_jurados);
    }
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/29.0.0/classic/ckeditor.js"></script>
    <script>
        //CKEDITOR
            ClassicEditor
                .create( document.querySelector( '#descripcion' ), {
                    toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'blockQuote' ],
                    heading: {
                        options: [
                            { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                            { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                            { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
                        ]
                    }
                } )
                .catch( error => {
                    console.log( error );
                } );
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/admin/revisiontesis.blade.php ENDPATH**/ ?>