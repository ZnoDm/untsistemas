
<?php $__env->startSection('title', 'Practicas Pendientes'); ?>
<?php $__env->startSection('content_header'); ?>
    <div class="d-flex">
        <h1 class="mr-auto">Solicitud de Practica</h1>
    </div>    
    <hr class="mt-3">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <h2 class="my-5 font-weight-bold text-center"> PLAN DE PRACTICA </h5>
        <div class="row gx-2">
            <!--ASIDE-->
            <div class="col-4">

                <div class="text-center">
                    <img class="h-16 w-16 rounded-circle img-fluid" style="width: 200px" src="<?php echo e(Auth::user()->profile_photo_url); ?>" alt="<?php echo e(Auth::user()->name); ?>" />
                </div><br><br>

                <hr class="my-3 mx-4">

                <div class="text-center">
                    <h5 class="pb-3 font-weight-bold">INFORMACION DEL ALUMNO </h5>

                    <p><span class="font-weight-bold">Código de matricula</span> <br> 
                        <?php echo e($practica->alumno_codigo); ?></p>

                    <p><span class="font-weight-bold">Apellidos y Nombres</span> <br> 
                        <?php echo e($practica->apellido.' '.$practica->nombre); ?></p>
                
                </div>        
                <hr class="my-3 mx-4">
                <div class="text-center">
                    <h5 class="pb-3 font-weight-bold">CONTACTO </h5>
                    <p><span class="font-weight-bold"> Email</span> <br>
                    <?php echo e($practica->email); ?></p>

                    <p><span class="font-weight-bold">Télefono</span> <br>
                        <?php echo e($practica->telefono); ?></p>  
                </div>
            </div>  

            <div class="col-8 px-3">

                <!--PRACTICA-->

                <h5 class="font-weight-bold">Asunto</h5>
                <?php echo $practica->descripcion; ?>


                <p> <span class="">Fecha de Incio: </span><?php echo e($practica->fecha_inicio); ?> </p> 
                <p> <span class="">Fecha de Fin: </span><?php echo e($practica->fecha_fin); ?> </p> 

                <div class="d-flex justify-content-center">                    
                    <a href="<?php echo e($practica->file_practica); ?>" class="button" download><i class="fa fa-download"></i> Descargar Plan de Practica</a>
                </div>

                <hr class="my-3 mx-3">

                <!--VOUCHER-->
                <h5 class="font-weight-bold pb-3"> Voucher </h5>

                <p> <span class="">Numero de Operacion: </span><?php echo e($practica->practica_id); ?> </p>

                <div class="d-flex justify-content-center">                    
                    <a href="<?php echo e($practica->file_voucher); ?>" class="button" download><i class="fa fa-download"></i> Descargar Voucher</a>
                </div>

                <hr class="my-3 mx-3">


                <!--PRACTICA-->
                <h5 class="font-weight-bold pb-3"> Empresa</h5>
                
                <p><?php echo e($practica->ruc); ?></p>
                <p><?php echo e($practica->razonsocial); ?></p>
                <p><?php echo e($practica->representante); ?></p>
                <p><?php echo e($practica->supervisor); ?></p>
                <p><?php echo e($practica->e_telefono); ?></p>

                <div class="d-flex text-center justify-content-center">
                    <?php
                        if($practica->status == 5 ) {$estado= 5;} else {$estado= 3;}
                    ?>
                        <form action="<?php echo e(route('admin.practica.aprobar',['id'=>$practica->id,'alumno' =>$practica->alumno_codigo,'estado' =>$estado])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success mx-2">APROBAR</button>
                        </form>

                        <button type="button" class="btn btn-danger mx-2" data-toggle="modal" data-target="#exampleModal">
                            DENEGAR
                        </button>
                    
                    
                </div>
            </div>
        </div>

    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Mandar Correcciones</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="p-2">
            <form action="<?php echo e(route('admin.practica.denegar',['id'=>$practica->id,'alumno' =>$practica->alumno_codigo])); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label for="descripcion">Observaciones:</label>
                <textarea name="descripcion" id="descripcion" cols="30" rows="10" class="mb-2"></textarea>
                <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="submit" value="Enviar" class="btn btn-success w-full btn-block mt-2">
            </form>
        </div>
        
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.ckeditor.com/ckeditor5/29.0.0/classic/ckeditor.js"></script>
    <script>
        //CKEDITOR
            ClassicEditor
                .create( document.querySelector( '#descripcion' ), {
                    toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'blockQuote' ],
                    heading: {
                        options: [
                            { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                            { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                            { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
                        ]
                    }
                } )
                .catch( error => {
                    console.log( error );
                } );
    </script>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/admin/revision.blade.php ENDPATH**/ ?>