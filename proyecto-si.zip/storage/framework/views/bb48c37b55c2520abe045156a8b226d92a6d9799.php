<?php if (isset($component)) { $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlumnoLayout::class, []); ?>
<?php $component->withName('alumno-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <!-- component -->
    
 <?php if (isset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11)): ?>
<?php $component = $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11; ?>
<?php unset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/alumno/index.blade.php ENDPATH**/ ?>