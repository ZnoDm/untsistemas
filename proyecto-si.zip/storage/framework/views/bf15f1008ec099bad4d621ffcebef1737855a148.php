<?php if (isset($component)) { $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlumnoLayout::class, []); ?>
<?php $component->withName('alumno-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <!-- component -->
    
    <div class="max-w-xl mx-auto my-4 pb-4">	
        <div class="flex pb-3">
            <div class="flex-1">
            </div>
            <div class="flex-1">
                <div class="<?php echo e(!$status ? 'border-2' : 'bg-green-500 text-white'); ?> w-10 h-10 mx-auto rounded-full text-lg flex items-center">
                    <span class="text-center w-full"> <?php if(!$status): ?> 1 <?php else: ?> <i class="fas fa-check"></i> <?php endif; ?> </span>
                </div>
                <div class="text-center pt-2">
                    Solicitud
                </div>
            </div>
            
            <div class="w-1/4 align-center items-center align-middle content-center flex item pb-6">
                <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
                    <div class="bg-green-500 text-xs leading-none py-1 text-center rounded " style="width: <?php echo e(!$status ? '0%' : '100%'); ?>"></div>
                </div>
            </div>
        
            <div class="flex-1">
                <div class="<?php echo e(($status ==2) ? 'bg-green-500 text-white': (($status==3) ? 'bg-red-500 text-white':'border-2')); ?> w-10 h-10 mx-auto rounded-full text-lg  flex items-center">
                    <span class="text-center w-full"><?php if($status==2): ?> <i class="fas fa-check"></i> <?php else: ?>  <?php if($status==3): ?> <i class="fas fa-times"></i> <?php else: ?>  2 <?php endif; ?>  <?php endif; ?></span>
                </div>
                <div class="text-center pt-2">
                    <?php if($status==2): ?> Aprobada <?php else: ?>  <?php if($status==3): ?> Rechazada <?php else: ?> Revisión <?php endif; ?>  <?php endif; ?> </i>
                </div>
            </div>
        
            <div class="w-1/4 align-center items-center align-middle content-center flex pb-6">
                <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
                    <div class="bg-green-500 text-xs leading-none py-1 text-center rounded " style="width: <?php echo e(($status==4) ? '100%' : '0%'); ?>"></div>
                </div>
                
            </div>
        
            <div class="flex-1">
                <div class="<?php echo e(($status==4) ? 'bg-green-500 text-white' : 'border-2'); ?> w-10 h-10 mx-auto rounded-full text-lg  flex items-center">
                    <span class="text-center w-full"><?php if($status==4): ?> <i class="fas fa-check"></i> <?php else: ?> 3 <?php endif; ?> </span>
                </div>
                <div class="text-center pt-2">
                    Finalizada
                </div>
            </div>
        
            <div class="flex-1">
            </div>		
        </div>
    </div>

    <hr class="my-3"> 
    <?php if(session('info')): ?>
        <div class="bg-green-200 border border-green-400 text-green-700 px-4 py-3 rounded relative" role="alert">
            <strong class="font-bold">Success!</strong>
            <span class="block sm:inline"><?php echo e(session('info')); ?></span>
            <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
              <svg class="fill-current h-6 w-6 text-green-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
            </span>
        </div>
    <?php endif; ?>
    
   
    <?php switch($status):
        case (1): ?>
            <h3 class="text-center">Practica en REVISION.</h3>
            <?php break; ?>
        <?php case (2): ?>
            <h3 class="text-center">Practica ACEPTADA.</h3>
             <!-- Contador regresivo -->
            <?php if(!is_null($practica)): ?>
                <section class="text-center pt-5">
                    <h2>Cuenta Regresiva</h2>
                    <input type="hidden" name="fecha" id="fecha" value="<?php echo e($practica->end_date); ?>">
                    <div id="countdown"></div>
                </section>
            <?php endif; ?> 
            <?php break; ?>
        <?php case (3): ?>
            <h3 class="text-center">Practica RECHAZADA.</h3>
            <?php break; ?>
        <?php case (4): ?>
            <h3 class="text-center">Practica FINALIZADA.</h3>
            <?php break; ?>
        <?php default: ?>
            <!-- NUNCA ENVIO NADA -->
            <form action="<?php echo e(route('alumno.practicas.solicitud')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <h2>Solicitud: </h2>
                <div class="mb-4">
                    <label for="solicitud">Asunto:</label>
                    <input type="text" name="solicitud" class="w-full">
                    <?php $__errorArgs = ['solicitud"'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>
                        <strong class="text-red-500"><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="mb-4">
                    <label for="description">Descripcion:</label>
                    <textarea name="description" id="description" cols="30" rows="10" class="mb-2"></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>
                        <strong class="text-red-500"><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <hr class="my-3">
                <h2>Voucher: </h2>
                <div class="mb-4">
                    <div class="mb-2 grid grid-cols-2 gap-4">
                        <div>
                            <label for="num_operacion">Número de Operacion:</label>
                            <input type="text" name="num_operacion" id="num_operacion" class="w-full">
                            <?php $__errorArgs = ['num_operacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span>
                                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label for="file_voucher">Adjunte Recibo:</label>
                            <input type="file" name="file_voucher" id="file_voucher" class="w-full">
                            <?php $__errorArgs = ['file_voucher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span>
                                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>

                <hr class="my-3">
                <h2>Plan de Practicas: </h2>
                <div class="mb-4">
                    <div class="mb-4 grid grid-cols-2 gap-4">
                        <div>
                            <label for="start_date">Fecha de inicio:</label>
                            <input type="date" name="start_date" id="start_date" class="w-full">
                            <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span>
                                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label for="end_date">Fecha a Finalizar:</label>
                            <input type="date" name="end_date" id="end_date" class="w-full">
                            <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span>
                                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div>
                        <label for="file_practica">Adjunte Plan de Practicas:</label>
                        <input type="file" name="file_practica" id="file_practica" class="w-full">
                        <?php $__errorArgs = ['file_practica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span>
                                <strong class="text-red-500"><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                
            
                <input type="submit" value="Solicitar" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-full mt-2 cursor-pointer">
            </form>
    <?php endswitch; ?>
    
    
    <script>
        var variable = document.getElementById('fecha').value;
        console.log(variable)
        document.addEventListener("DOMContentLoaded", (e)=>{
        countdown("countdown",variable,"LLegaste al final 🤖");
        });
        function countdown(id,limiteDate,finalMessage){
            const $docx = document.getElementById(id);
            const countdownDate = new Date(limiteDate).getTime();

            let countdownTiempo = setInterval(()=>{
                let ahora = new Date().getTime(),
                limitTime = countdownDate - ahora,
                days= Math.floor(limitTime/(1000*60*60*24)),
                hours = ("0" + Math.floor((limitTime % (1000*60*60*24))/(1000*60*60))).slice(-2),
                minutes = ("0" + Math.floor((limitTime % (1000*60*60))/(1000*60))).slice(-2),
                seconds = ("0" + Math.floor((limitTime % (1000*60))/1000)).slice(-2);
                
                $docx.innerHTML = `<h3> Faltan: ${days} días, ${hours} horas ${minutes} minutos ${seconds} segundos</h3>`;    
                if(limitTime < 0){
                    clearInterval(countdownTiempo);
                    $docx.innerHTML = `<h3>${finalMessage}</h3>`;    
                }

            },1000);
        }
      </script>
    <script src="https://cdn.ckeditor.com/ckeditor5/29.0.0/classic/ckeditor.js"></script>
    <script>
        //CKEDITOR
            ClassicEditor
                .create( document.querySelector( '#description' ), {
                    toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'blockQuote' ],
                    heading: {
                        options: [
                            { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                            { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                            { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
                        ]
                    }
                } )
                .catch( error => {
                    console.log( error );
                } );
    </script>
    
 <?php if (isset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11)): ?>
<?php $component = $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11; ?>
<?php unset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/alumno/practicas/index.blade.php ENDPATH**/ ?>