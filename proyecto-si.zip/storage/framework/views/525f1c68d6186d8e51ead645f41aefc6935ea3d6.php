

<?php $__env->startSection('title', 'Alumnos'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Lista de Alumnos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-alumnos')->html();
} elseif ($_instance->childHasBeenRendered('EXv4Seg')) {
    $componentId = $_instance->getRenderedChildComponentId('EXv4Seg');
    $componentTag = $_instance->getRenderedChildComponentTagName('EXv4Seg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EXv4Seg');
} else {
    $response = \Livewire\Livewire::mount('admin-alumnos');
    $html = $response->html();
    $_instance->logRenderedChild('EXv4Seg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/admin/alumnos.blade.php ENDPATH**/ ?>