<?php if (isset($component)) { $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlumnoLayout::class, []); ?>
<?php $component->withName('alumno-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <h1 class="text-2xl font-bold mt-5">PLAN DE PRÁCTICAS</h1>
    <div class="p-5">
            <p>
                Como requisito para iniciar las prácticas, el estudiante no debe adeudar ningún curso hasta el <span class="font-bold">VIII Ciclo</span> , y al iniciarlas debe registrar su plan de prácticas dentro de los primeros 15 días de haberlas iniciado.
            </p>
            <!-- component -->
            <div class="container">
                <div class="flex flex-col md:grid grid-cols-9 mx-auto p-2 text-blue-50">
                    <!-- left -->
                    <div class="flex flex-row-reverse md:contents">
                        <div class="bg-blue-500 col-start-1 col-end-5 p-4 rounded-xl my-4 ml-auto shadow-md">
                            <h3 class="font-semibold text-lg mb-1">VOUCHER DE TRÁMITE</h3>
                            <p class="leading-tight text-justify">
                            Voucher de trámite S/. 5.00 (grabado en un solo archivo).                  
                            </p>
                            <p>Depósitos en Bancos:</p>
                            <ul>
                                <li><i class="fa fa-university" aria-hidden="true"></i> Interbank</li>
                                <li><i class="fa fa-university" aria-hidden="true"></i> Financiera Confianza</li>
                            </ul>
                        </div>
                        <div class="col-start-5 col-end-6 md:mx-auto relative mr-10">
                            <div class="h-full w-6 flex items-center justify-center">
                                <div class="h-full w-1 bg-blue-800 pointer-events-none"></div>
                            </div>
                            <div class="w-6 h-6 absolute top-1/2 -mt-3 rounded-full bg-blue-500 shadow"></div>
                        </div>
                    </div>
                    <!-- right -->
                    <div class="flex md:contents">
                        <div class="col-start-5 col-end-6 mr-10 md:mx-auto relative">
                            <div class="h-full w-6 flex items-center justify-center">
                                <div class="h-full w-1 bg-blue-800 pointer-events-none"></div>
                            </div>
                            <div class="w-6 h-6 absolute top-1/2 -mt-3 rounded-full bg-blue-500 shadow"></div>
                        </div>
                        <div class="bg-blue-500 col-start-6 col-end-10 p-4 rounded-xl my-4 mr-auto shadow-md" >
                            <h3 class="font-semibold text-lg mb-1">ARCHIVO PLAN DE PRACTICA</h3>
                            <div class="grid grid-cols-3 gap-4">
                                <div class="col-span-2">
                                    <p class="leading-tight">
                                    Un (01) ejemplar del Plan de Prácticas (grabado en un solo archivo).
                                    </p>
                                </div>
                                <div class="mx-auto"> 
                                    <a href="<?php echo e(asset('example_archivos/example_plan.pdf')); ?>" class="button" download><img src="<?php echo e(asset('img/pdf.png')); ?>" alt="example_plan.pdf" style="width: 50px" class="mx-auto"></a>
                                    <p>Descargar</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- left -->
                    <div class="flex flex-row-reverse md:contents">
                        <div class="bg-blue-500 col-start-1 col-end-5 p-4 rounded-xl my-4 ml-auto shadow-md">
                            <h3 class="font-semibold text-lg mb-1">HACER SU SOLICITUD DE PRACTICA</h3>
                            <p class="leading-tight text-justify">
                                Formato unico de trámite                  
                            </p>
                        </div>
                        <div class="col-start-5 col-end-6 md:mx-auto relative mr-10">
                            <div class="h-full w-6 flex items-center justify-center">
                                <div class="h-full w-1 bg-blue-800 pointer-events-none"></div>
                            </div>
                            <div class="w-6 h-6 absolute top-1/2 -mt-3 rounded-full bg-blue-500 shadow"></div>
                        </div>
                    </div>
                </div>
            </div>
    </div>
        
 <?php if (isset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11)): ?>
<?php $component = $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11; ?>
<?php unset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/alumno/practicas/requisitos.blade.php ENDPATH**/ ?>