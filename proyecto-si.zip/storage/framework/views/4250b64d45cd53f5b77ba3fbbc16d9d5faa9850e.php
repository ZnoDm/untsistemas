<?php if (isset($component)) { $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlumnoLayout::class, []); ?>
<?php $component->withName('alumno-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php
        $status = $practica->status;
    ?>
    <h2 class="text-xl font-bold mb-5">PROGRESO</h2>
    <div class="">	
        <div class="flex pb-3">
            <div class="flex-1">
            </div>
            <div class="flex-1">
                <div class="<?php echo e(!$status ? 'border-2' : 'bg-green-500 text-white'); ?> w-10 h-10 mx-auto rounded-full text-lg flex items-center">
                    <span class="text-center w-full"> <?php if(!$status): ?> 1 <?php else: ?> <i class="fas fa-check"></i> <?php endif; ?> </span>
                </div>
                <div class="text-center pt-2">
                    Aceptada
                </div>
            </div>
            
            <div class="w-1/4 align-center items-center align-middle content-center flex item pb-6">
                <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
                    <div class="bg-green-500 text-xs leading-none py-1 text-center rounded " style="width: <?php echo e(!$status ? '0%' : '100%'); ?>"></div>
                </div>
            </div>
        
            <div class="flex-1">
                <div class="<?php echo e(($status ==4) ? 'bg-green-500 text-white': (($status==3) ? 'bg-red-500 text-white':'border-2')); ?> w-10 h-10 mx-auto rounded-full text-lg  flex items-center">
                    <span class="text-center w-full"><?php if($status==4): ?> <i class="fas fa-check"></i> <?php else: ?>  <?php if($status==3): ?> <i class="fas fa-times"></i> <?php else: ?>  2 <?php endif; ?>  <?php endif; ?></span>
                </div>
                <div class="text-center pt-2">
                    Informe Final</i>
                </div>
            </div>
        
            <div class="w-1/4 align-center items-center align-middle content-center flex pb-6">
                <div class="w-full bg-gray-200 rounded items-center align-middle align-center flex-1">
                    <div class="bg-green-500 text-xs leading-none py-1 text-center rounded " style="width: <?php echo e(($status==4) ? '100%' : '0%'); ?>"></div>
                </div>
                
            </div>
        
            <div class="flex-1">
                <div class="<?php echo e(($status==4) ? 'bg-green-500 text-white' : 'border-2'); ?> w-10 h-10 mx-auto rounded-full text-lg  flex items-center">
                    <span class="text-center w-full"><?php if($status==4): ?> <i class="fas fa-check"></i> <?php else: ?> 3 <?php endif; ?> </span>
                </div>
                <div class="text-center pt-2">
                    Finalizada
                </div>
            </div>
        
            <div class="flex-1">
            </div>		
        </div>
    </div>
    <?php if($status == 5): ?>
        <h2 class="text-xl font-bold mt-10 text-center">INFORME FINAL ENVIADO EN REVISION</h2>
    <?php else: ?>
        <?php if($status == 4): ?>
            <h2 class="text-xl font-bold mt-10 text-center">PRACTICA FINALIZADA</h2> 
        <?php else: ?>
            <?php if($status == 6): ?>
            <h2 class="text-xl font-bold">OBSERVACIONES</h2>

            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
                <p class="font-bold">Solucionar:</p>
                <?php $__currentLoopData = $prac->observations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo $observacion->mensaje; ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <hr class="my-3">
            <?php endif; ?>
            <h2 class="text-xl font-bold mt-10">FECHA LIMITE</h2>
            <?php
                $time=strtotime($practica->fecha_fin);
            ?>
            <div class="grid grid-cols-3 gap-4">
                <div class=""></div>
                <div class="rounded-t lg:rounded-t-none lg:rounded-l text-center shadow-lg ">
                <div class="rounded-t overflow-hidden  text-center ">
                    <div class="bg-blue-600 text-white py-1">
                        <?php echo e(date("F", $time)); ?>

                    </div>
                    <div class="pt-1 border-l border-r border-white bg-white">
                    <span class="text-5xl font-bold leading-tight">
                        <?php echo e(date("d", $time)); ?>

                    </span>
                    </div>
                    <div class="border-l border-r border-b rounded-b-lg text-center border-white bg-white -pt-2 -mb-1">
                    <span class="text-sm">
                        <?php echo e(date("D", $time)); ?>

                    </span>
                    </div>
                    <div class="pb-2 border-l border-r border-b rounded-b-lg text-center border-white bg-white">
                    <span class="text-xs leading-normal">
                        Antes de 12:00 pm
                    </span>
                    </div>
                </div>
                </div>
                <div class=""></div>
            </div>
        
            <h2 class="text-xl font-bold mt-10">INFORME FINAL</h2>
            <form action="<?php echo e(route('practica.informefinal')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="practica_id" id="practica_id" value="<?php echo e($practica->practica_id); ?>">
                <div class="my-4">
                    <div class="mb-2 ">
                        <div>
                            <input type="file" name="file_informe_final" id="file_informe_final" class="w-full" accept=".pdf">
                            <?php $__errorArgs = ['file_informe_final'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span>
                                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
        
                
                <input type="submit" value="Enviar" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-full mt-2 cursor-pointer">
            </form>
        <?php endif; ?> 
    
    <?php endif; ?>
 <?php if (isset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11)): ?>
<?php $component = $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11; ?>
<?php unset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/alumno/practica/progreso.blade.php ENDPATH**/ ?>