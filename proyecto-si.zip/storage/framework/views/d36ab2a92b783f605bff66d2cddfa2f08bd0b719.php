
<?php $__env->startSection('title', 'Calificar'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <h3 class="font-bold text-center">CALIFICACIONES DE JURADOS</h3>
        <form action="<?php echo e(route('admin.tesis.calificando')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php
                $array[] = "";
                
            ?>
            <?php $__currentLoopData = $jurados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    array_push($array, $jurado->nombre);
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" name="tesis_id" value="<?php echo e($tesis->id); ?>">
            <input type="hidden" name="codigo" value="<?php echo e($tesis->alumno_codigo); ?>">
            <div class="pb-3">  
            <p class="form-control"><?php echo e($array[1]); ?></p>
            <label for="">Nota 1:</label>
            <input type="text" id="nota1" name="nota1" class="is-invalid" onKeyPress="return soloNumeros(event)">
            <?php $__errorArgs = ['nota1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                        <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="pb-3">         
            <p class="form-control"><?php echo e($array[2]); ?></p>
            <label for="">Nota 2:</label>
            <input type="text" id="nota2" name="nota2" class="is-invalid" onKeyPress="return soloNumeros(event)">
            <?php $__errorArgs = ['nota2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="pb-3">
            <p class="form-control"><?php echo e($array[3]); ?></p>
            <label for="">Nota 3:</label>
            <input type="text" id="nota3" name="nota3" class="is-invalid" onKeyPress="return soloNumeros(event)">
            <?php $__errorArgs = ['nota3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <br> <br>
            <input type="submit" value="Enviar" class="btn btn-success w-100">
        </form>
    </div>
    <script type="text/javascript">
        // Solo permite ingresar numeros.
        function soloNumeros(e){
            var key = window.Event ? e.which : e.keyCode
            return (key >= 48 && key <= 57)
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/admin/tesis/calificar.blade.php ENDPATH**/ ?>