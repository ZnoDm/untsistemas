<?php if (isset($component)) { $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlumnoLayout::class, []); ?>
<?php $component->withName('alumno-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div>
    <h1 class="text-2xl font-bold mt-5">PROCEDIMIENTOS Y REQUISITOS DE PRÁCTICAS</h1>
    <p class="p-5">
        Como requisito para iniciar las prácticas, el estudiante no debe adeudar ningún curso hasta el VIII Ciclo, y al iniciarlas debe registrar su plan de prácticas dentro de los primeros 15 días de haberlas iniciado.

    </p>
    <div>
        <div class="lg:px-10 pb-5">
            <div class='grid grid-cols-3 h-full pb-4'>
                <div class="mx-3">
                    <div class=" pb-3 mt-5 h-6/6 relative bg-green-100 group hover:bg-green-200 cursor-pointer transition ease-out duration-300"> 
                        <div class="p-5">
                            <img src="<?php echo e(asset('img/InterBank-logo.png')); ?>" alt="InterBank-logo" class="object-fill">
                        </div>
                        <div class="px-7 mt-5">
                            <h1 class="text-3xl font-bold group-hover:text-green-300 transition ease-out duration-300">01.</h1>
                            <h2  class="text-1xl mt-4 font-bold">Los pagos se realiza en las cuentas:</h2>
                            <p class="mt-2 opacity-60 group-hover:opacity-70 ">
                                <span class="font-bold">Interbank</span> – Cuenta Nº 6163001972909
                                        CCI Nº 00361600300197290901
                                <span class="font-bold">Financiera Confianza</span> – Cuenta N°  003021000187671001
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="mx-3">
                    <div class="pb-3 mt-32 h-6/6 relative bg-indigo-100 group hover:bg-indigo-200 cursor-pointer transition ease-out duration-300"> 
                        <div class="p-5">
                            <img src="<?php echo e(asset('img/example_voucher.jpeg')); ?>" alt="example_voucher" class="object-contain">
                        </div>
                    <div class="px-7 mt-18">
                            <h1 class="text-3xl font-bold group-hover:text-indigo-300 transition ease-out duration-300">02.</h1>
                            <h2  class="text-1xl mt-4 font-bold">VOUCHER DE TRÁMITE</h2>
                            <p class="mt-2 opacity-60 group-hover:opacity-70 ">Precio S/. 5.00 (grabado en un solo archivo)
                        </div>
                    </div>
                </div>
                <div class="border-gray-300 mx-3">
                    <div class="pb-3 mt-72 h-4/6 relative bg-purple-100 group hover:bg-purple-200 cursor-pointer transition ease-out duration-300"> 
                        <div class="p-5">
                            <img src="<?php echo e(asset('img/example_plan.jpg')); ?>" alt="example_plan.jpg" class="object-contain">
                        </div>
                        <div class="px-7 mt-19">
                            <h1 class="text-3xl font-bold group-hover:text-purple-300 transition ease-out duration-300">01.</h1>
                            <h2  class="text-1xl mt-4 font-bold">Roof light lamp</h2>
                            <p class="mt-2 opacity-60 group-hover:opacity-70 ">Diverse collection of roof lights of quality</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
 <?php if (isset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11)): ?>
<?php $component = $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11; ?>
<?php unset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/alumno/tramites.blade.php ENDPATH**/ ?>