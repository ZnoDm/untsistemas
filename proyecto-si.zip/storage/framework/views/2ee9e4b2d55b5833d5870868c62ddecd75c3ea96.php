<?php if (isset($component)) { $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlumnoLayout::class, []); ?>
<?php $component->withName('alumno-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <h1 class="text-center text-xl font-bold">Actualizar Solicitud de Practica</h1>
    <?php if($alumno_practica->status == 3): ?>
        <h2 class="text-xl font-bold">OBSERVACIONES</h2>

        <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4" role="alert">
            <p class="font-bold">Solucionar:</p>
            <?php $__currentLoopData = $practica->observations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo $observacion->mensaje; ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <hr class="my-3">
    <?php endif; ?>
    <form action="<?php echo e(route('practica.update',$practica)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <div>
            <label for="descripcion">Asunto:</label>
            <textarea name="descripcion" id="descripcion" cols="30" rows="10" class="mb-2"><?php echo e(old('descripcion',$practica->descripcion)); ?></textarea>
            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span>
                <strong class="text-red-500"><?php echo e($message); ?></strong>
            </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <div class="my-4 grid grid-cols-2 gap-4">
            <div>
                <label for="fecha_inicio">Fecha de inicio:</label>
                <input type="date" name="fecha_inicio" id="fecha_inicio" class="w-full" value="<?php echo e(old('fecha_inicio',$practica->fecha_inicio)); ?>">
                <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>
                        <strong class="text-red-500"><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="fecha_fin">Fecha a Finalizar:</label>
                <input type="date" name="fecha_fin" id="fecha_fin" class="w-full" value="<?php echo e(old('fecha_fin',$practica->fecha_fin)); ?>">
                <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>
                        <strong class="text-red-500"><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div>
            <label for="file_practica">Adjunte Plan de Practicas:</label>
            <input type="file" name="file_practica" id="file_practica" class="w-full" value="<?php echo e(old('file_practica',$practica->file_practica)); ?>">
            <?php $__errorArgs = ['file_practica'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <hr class="my-3">

        <h2 class="font-bold">Asesor: </h2>

        <div class="mb-4">
            <div>
                <select name="docente_id" id="docente_id" class="w-full">
                    <option value="">SELECCIONA UN DOCENTE</option>
                    <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($docente->id); ?>" <?php echo e($docente->id==$alumno_practica->docente_id ? 'selected':''); ?>> <?php echo e($docente->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <hr class="my-3">

        <h2 class="font-bold">Voucher: </h2>

        <div class="mb-4">
            <div class="mb-2 grid grid-cols-2 gap-4">
                <div>
                    <label for="nro">Número de Operacion:</label>
                    <input type="text" name="nro" id="nro" class="w-full" value="<?php echo e(old('nro',$practica->voucher->nro)); ?>">
                    <?php $__errorArgs = ['nro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>
                            <strong class="text-red-500"><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="file_voucher">Adjunte Recibo:</label>
                    <input type="file" name="file_voucher" id="file_voucher" class="w-full">
                    <?php $__errorArgs = ['file_voucher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>
                            <strong class="text-red-500"><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <hr class="my-3">
        <h2 class="font-bold">Empresa: </h2>
        <div class="mb-4">
            <div class="mb-2 grid grid-cols-2 gap-4">
                <div>
                    <label for="ruc">RUC:</label>
                    <input type="text" name="ruc" id="ruc" class="w-full" value="<?php echo e(old('ruc',$practica->empresa->ruc)); ?>">
                    <?php $__errorArgs = ['ruc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>
                            <strong class="text-red-500"><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="nombre">RAZON SOCIAL:</label>
                    <input type="text" name="nombre" id="nombre" class="w-full" value="<?php echo e(old('nombre',$practica->empresa->nombre)); ?>">
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>
                            <strong class="text-red-500"><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div>
                <label for="representante">REPRESENTANTE:</label>
                <input type="text" name="representante" id="representante" class="w-full" value="<?php echo e(old('representante',$practica->empresa->representante)); ?>">
                <?php $__errorArgs = ['representante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>
                        <strong class="text-red-500"><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="my-2 grid grid-cols-2 gap-4">
                <div>
                    <label for="supervisor">SUPERVISOR:</label>
                    <input type="text" name="supervisor" id="supervisor" class="w-full" value="<?php echo e(old('supervisor',$practica->empresa->supervisor)); ?>">
                    <?php $__errorArgs = ['supervisor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>
                            <strong class="text-red-500"><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="telefono">TELEFONO:</label>
                    <input type="text" name="telefono" id="telefono" class="w-full" value="<?php echo e(old('telefono',$practica->empresa->telefono)); ?>">
                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>
                            <strong class="text-red-500"><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>
        
        
        <input type="submit" value="<?php if($alumno_practica->status == 3): ?> Solicitar <?php else: ?> Actualizar Informacion <?php endif; ?>" class="<?php echo e(($alumno_practica->status == 3) ? 'bg-green-500 hover:bg-green-700' : 'bg-blue-500 hover:bg-blue-700'); ?> text-white font-bold py-2 px-4 rounded w-full mt-2 cursor-pointer">        
    
        </form>
    
    
    <script src="https://cdn.ckeditor.com/ckeditor5/29.0.0/classic/ckeditor.js"></script>
    <script>
        //CKEDITOR
            ClassicEditor
                .create( document.querySelector( '#descripcion' ), {
                    toolbar: [ 'heading', '|', 'bold', 'italic', 'link', 'blockQuote' ],
                    heading: {
                        options: [
                            { model: 'paragraph', title: 'Paragraph', class: 'ck-heading_paragraph' },
                            { model: 'heading1', view: 'h1', title: 'Heading 1', class: 'ck-heading_heading1' },
                            { model: 'heading2', view: 'h2', title: 'Heading 2', class: 'ck-heading_heading2' }
                        ]
                    }
                } )
                .catch( error => {
                    console.log( error );
                } );
    </script>
    
 <?php if (isset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11)): ?>
<?php $component = $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11; ?>
<?php unset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/alumno/practica/edit.blade.php ENDPATH**/ ?>