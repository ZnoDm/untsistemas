<?php if (isset($component)) { $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AlumnoLayout::class, []); ?>
<?php $component->withName('alumno-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    
    <h1 class="text-center text-xl font-bold">Solicitud de Tesis</h1>
    <?php if(session('info')): ?>
    <div class="bg-red-200 border border-red-400 text-red-700 px-4 py-3 rounded relative my-2" role="alert">
        <strong class="font-bold">Error!</strong>
        <span class="block sm:inline"><?php echo e(session('info')); ?></span>
        <span class="absolute top-0 bottom-0 right-0 px-4 py-3">
          <svg class="fill-current h-6 w-6 text-red-500" role="button" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><title>Close</title><path d="M14.348 14.849a1.2 1.2 0 0 1-1.697 0L10 11.819l-2.651 3.029a1.2 1.2 0 1 1-1.697-1.697l2.758-3.15-2.759-3.152a1.2 1.2 0 1 1 1.697-1.697L10 8.183l2.651-3.031a1.2 1.2 0 1 1 1.697 1.697l-2.758 3.152 2.758 3.15a1.2 1.2 0 0 1 0 1.698z"/></svg>
        </span>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('tesis.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <h2 class="font-bold">Titulo: </h2>
        <div>
            <input type="text" name="titulo" id="titulo" class="w-full" value="<?php echo e(old('titulo')); ?>">
            <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <hr class="my-3">
        <h2 class="font-bold">Asesor: </h2>

        <div class="mb-4">
            <div>
                <select name="docente_id" id="docente_id" class="w-full">
                    <option value="">SELECCIONA UN DOCENTE</option>
                    <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($docente->id); ?>"><?php echo e($docente->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>
        <hr class="my-3">
        
        <h2 class="font-bold">Documento F-003-B FORMATO DE TITULO : </h2>
        <p>Debe ser firmado por el asesor de lo contrario, será rechazado</p>
        <div>
            <input type="file" name="file_tesis" id="file_tesis" class="w-full" accept=".pdf">
            <?php $__errorArgs = ['file_tesis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span>
                    <strong class="text-red-500"><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <hr class="my-3">

        <div class="my-4 grid grid-cols-2 gap-4">
            <div>
                <label for="fecha_inicio">Fecha de inicio:</label>
                <input type="date" name="fecha_inicio" id="fecha_inicio" class="w-full" value="<?php echo e(old('fecha_inicio')); ?>">
                <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>
                        <strong class="text-red-500"><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="fecha_fin">Fecha a Finalizar:</label>
                <input type="date" name="fecha_fin" id="fecha_fin" class="w-full" value="<?php echo e(old('fecha_fin')); ?>">
                <?php $__errorArgs = ['fecha_fin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span>
                        <strong class="text-red-500"><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <hr class="my-3">

        <h2 class="font-bold">Voucher: </h2>

        <div class="mb-4">
            <div class="mb-2 grid grid-cols-2 gap-4">
                <div>
                    <label for="nro">Número de Operacion:</label>
                    <input type="text" name="nro" id="nro" class="w-full" value="<?php echo e(old('nro')); ?>">
                    <?php $__errorArgs = ['nro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>
                            <strong class="text-red-500"><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <label for="file_voucher">Adjunte Recibo:</label>
                    <input type="file" name="file_voucher" id="file_voucher" class="w-full" accept="image/*">
                    <?php $__errorArgs = ['file_voucher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span>
                            <strong class="text-red-500"><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>       
        <input type="submit" value="Solicitar" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-full mt-2 cursor-pointer">
    </form>
    
 <?php if (isset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11)): ?>
<?php $component = $__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11; ?>
<?php unset($__componentOriginal12abd7441e0fd8b1b4cca03e29d8c860bfc89c11); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/alumno/tesis/create.blade.php ENDPATH**/ ?>