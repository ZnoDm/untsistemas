
<?php $__env->startSection('title', 'Asignar Fecha'); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-5">
        <form action="<?php echo e(route('admin.tesis.asignando_fecha')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <h5 class="font-weight-bold">Titulo</h5>
            <p class="form-control"> <?php echo e($tesis->titulo); ?> </p> 
            <h5 class="font-weight-bold text-center">ASIGNAR FECHA DE SUSTENTACION </h5>

            <hr class="my-3 mx-3">
            <input type="hidden" name="tesis_id" value="<?php echo e($tesis->id); ?>">
            <input type="hidden" name="codigo" value="<?php echo e($tesis->alumno_codigo); ?>">
            <div class="row px-5 mb-5"> 
                <input type="date" name="sustentacion" id="sustentacion" class="form-control w-25 mx-auto is-invalid" value="<?php echo e(old('sustentacion')); ?>">
                <?php $__errorArgs = ['sustentacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback text-center">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <input type="submit" value="ASIGNAR" class="btn btn-success w-100">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
    
<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/admin/tesis/asignar_fecha.blade.php ENDPATH**/ ?>