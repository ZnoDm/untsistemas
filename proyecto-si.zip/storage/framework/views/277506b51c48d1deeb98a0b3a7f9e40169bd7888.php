

<?php $__env->startSection('title', 'Empresas'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Listado de Empresas</h1>    
    <hr class="mt-3">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>RUC</th>
                    <th>NOMBRE</th>
                    <th>REPRESENTANTE LEGAL</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($empresa->ruc); ?></td>
                        <td><?php echo e($empresa->nombre); ?></td>
                        <td><?php echo e($empresa->representante); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/admin/empresas.blade.php ENDPATH**/ ?>