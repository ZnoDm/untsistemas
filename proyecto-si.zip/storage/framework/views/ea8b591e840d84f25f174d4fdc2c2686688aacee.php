<div>
    <div class="card">
        <div class="card-header">
            <input wire:keydown="limpiar_page" wire:model="search" class="form-control w-100" placeholder="Escriba un nombre...">
        </div>
        <?php if($alumnos->count()): ?>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Apellidos</th>
                            <th>Nombres</th>
                            <th>Email</th>
                            <th>Telefono</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($alumno->codigo); ?></td>
                                <td><?php echo e($alumno->apellido); ?></td>
                                <td><?php echo e($alumno->nombre); ?></td>
                                <td><?php echo e($alumno->email); ?></td>
                                <td><?php echo e($alumno->telefono); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="card-footer">
                <?php echo e($alumnos->links()); ?>

            </div>
        <?php else: ?>
            <div class="card-body"><strong>No hay registros</strong></div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\2021-SistemasdeInformacion\proyecto-si\resources\views/livewire/admin-alumnos.blade.php ENDPATH**/ ?>