<?php return array (
  'admin-alumnos' => 'App\\Http\\Livewire\\AdminAlumnos',
  'admin-docentes' => 'App\\Http\\Livewire\\AdminDocentes',
);